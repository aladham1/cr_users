<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Start Topbar -->
    <div class="h-[60px] bg-white dark:bg-dark dark:border-gray/20 border-b-2 border-lightgray/10 flex items-center justify-between gap-2.5 px-7">
        <div class="flex-auto flex items-center gap-2.5">
            <div class="lg:hidden">
                <button type="button" class="hover:text-primary" @click="$store.app.toggleSidebar()">
                    <svg width="13" height="12" class="rotate-180" viewBox="0 0 13 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path opacity="0.2" d="M5.46133 6.00002L11.1623 12L12.4613 10.633L8.05922 6.00002L12.4613 1.36702L11.1623 0L5.46133 6.00002Z" fill="currentColor" />
                        <path d="M0 6.00002L5.70101 12L7 10.633L2.59782 6.00002L7 1.36702L5.70101 0L0 6.00002Z" fill="currentColor" />
                    </svg>
                </button>
            </div>
            <div class="max-w-[180px] md:max-w-[350px] flex-1">
                <form class="hidden min-[420px]:block w-full">
                    <div class="relative">
                        <input type="text" id="search" class="form-input ps-10 h-[42px] dark:border-lightgray/20 dark:text-white dark:bg-lightgray/10 border-2 border-gray/10 bg-gray/[8%] rounded-full text-sm text-dark placeholder:text-lightgray/80 focus:ring-0 focus:border-primary/80 focus:outline-0" placeholder="Search..." required="">
                        <button type="button" class="absolute inset-y-0 left-3 flex items-center">
                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <g clip-path="url(#clip0_87_857)">
                                    <circle cx="8.625" cy="8.625" r="7.125" stroke="#267DFF" stroke-width="2" />
                                    <path opacity="0.3" d="M15 15L16.5 16.5" stroke="#267DFF" stroke-width="2" stroke-linecap="round" />
                                </g>
                                <defs>
                                    <clipPath id="clip0_87_857">
                                        <rect width="18" height="18" fill="white" />
                                    </clipPath>
                                </defs>
                            </svg>
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="sm:block hidden flex-auto">
            <ul class="flex items-center gap-[30px]">
                <li>
                    <a href="inbox.html" class="flex items-center gap-2.5 text-lightgray hover:text-primary duration-300 text-sm font-semibold">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M22 5C22 6.65685 20.6569 8 19 8C17.3431 8 16 6.65685 16 5C16 3.34315 17.3431 2 19 2C20.6569 2 22 3.34315 22 5Z" fill="currentColor" />
                            <path opacity="0.3" d="M15.612 2.03826C14.59 2 13.3988 2 12 2C7.28595 2 4.92893 2 3.46447 3.46447C2 4.92893 2 7.28595 2 12C2 16.714 2 19.0711 3.46447 20.5355C4.92893 22 7.28595 22 12 22C16.714 22 19.0711 22 20.5355 20.5355C22 19.0711 22 16.714 22 12C22 10.6012 22 9.41 21.9617 8.38802C21.1703 9.08042 20.1342 9.5 19 9.5C16.5147 9.5 14.5 7.48528 14.5 5C14.5 3.86584 14.9196 2.82967 15.612 2.03826Z" fill="currentColor" />
                            <path d="M3.46451 20.5355C4.92902 22 7.28611 22 12.0003 22C16.7145 22 19.0716 22 20.5361 20.5355C21.8931 19.1785 21.9927 17.0551 22 13H18.8402C17.935 13 17.4824 13 17.0846 13.183C16.6868 13.3659 16.3922 13.7096 15.8031 14.3968L15.1977 15.1032C14.6086 15.7904 14.314 16.1341 13.9162 16.317C13.5183 16.5 13.0658 16.5 12.1606 16.5H11.84C10.9348 16.5 10.4822 16.5 10.0844 16.317C9.68655 16.1341 9.392 15.7904 8.80291 15.1032L8.19747 14.3968C7.60837 13.7096 7.31382 13.3659 6.91599 13.183C6.51815 13 6.06555 13 5.16035 13H2C2.0073 17.0551 2.10744 19.1785 3.46451 20.5355Z" fill="currentColor" />
                        </svg>
                        <span class="lg:block hidden">Inbox</span>
                    </a>
                </li>
                <li>
                    <a href="chat.html" class="flex items-center gap-2.5 text-lightgray hover:text-primary duration-300 text-sm font-semibold">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M18 14C18 18.4183 14.4183 22 10 22C8.76449 22 7.5944 21.7199 6.54976 21.2198C6.19071 21.0479 5.78393 20.9876 5.39939 21.0904L4.17335 21.4185C3.20701 21.677 2.32295 20.793 2.58151 19.8267L2.90955 18.6006C3.01245 18.2161 2.95209 17.8093 2.7802 17.4502C2.28008 16.4056 2 15.2355 2 14C2 9.58172 5.58172 6 10 6C14.4183 6 18 9.58172 18 14ZM6.5 15C7.05228 15 7.5 14.5523 7.5 14C7.5 13.4477 7.05228 13 6.5 13C5.94772 13 5.5 13.4477 5.5 14C5.5 14.5523 5.94772 15 6.5 15ZM10 15C10.5523 15 11 14.5523 11 14C11 13.4477 10.5523 13 10 13C9.44772 13 9 13.4477 9 14C9 14.5523 9.44772 15 10 15ZM13.5 15C14.0523 15 14.5 14.5523 14.5 14C14.5 13.4477 14.0523 13 13.5 13C12.9477 13 12.5 13.4477 12.5 14C12.5 14.5523 12.9477 15 13.5 15Z" fill="currentColor" />
                            <path opacity="0.3" d="M17.9841 14.5084C18.092 14.4638 18.1984 14.4163 18.3033 14.3661C18.5951 14.2264 18.9256 14.1774 19.238 14.261L20.2342 14.5275C21.0193 14.7376 21.7376 14.0193 21.5275 13.2342L21.261 12.238C21.1774 11.9256 21.2264 11.595 21.3661 11.3033C21.7724 10.4545 22 9.50385 22 8.5C22 4.91015 19.0899 2 15.5 2C12.79 2 10.4673 3.6585 9.49156 6.0159C9.65969 6.00535 9.82922 6 10 6C14.4183 6 18 9.58172 18 14C18 14.1708 17.9946 14.3403 17.9841 14.5084Z" fill="currentColor" />
                        </svg>
                        <span class="lg:block hidden">Chat</span>
                    </a>
                </li>
                <li>
                    <a href="settings.html" class="flex items-center gap-2.5 text-lightgray hover:text-primary duration-300 text-sm font-semibold">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M12.4277 2C11.3139 2 10.2995 2.6007 8.27081 3.80211L7.58466 4.20846C5.55594 5.40987 4.54158 6.01057 3.98466 7C3.42773 7.98943 3.42773 9.19084 3.42773 11.5937V12.4063C3.42773 14.8092 3.42773 16.0106 3.98466 17C4.54158 17.9894 5.55594 18.5901 7.58466 19.7915L8.27081 20.1979C10.2995 21.3993 11.3139 22 12.4277 22C13.5416 22 14.5559 21.3993 16.5847 20.1979L17.2708 19.7915C19.2995 18.5901 20.3139 17.9894 20.8708 17C21.4277 16.0106 21.4277 14.8092 21.4277 12.4063V11.5937C21.4277 9.19084 21.4277 7.98943 20.8708 7C20.3139 6.01057 19.2995 5.40987 17.2708 4.20846L16.5847 3.80211C14.5559 2.6007 13.5416 2 12.4277 2Z" fill="currentColor" />
                            <path d="M12.4277 8.25C10.3567 8.25 8.67773 9.92893 8.67773 12C8.67773 14.0711 10.3567 15.75 12.4277 15.75C14.4988 15.75 16.1777 14.0711 16.1777 12C16.1777 9.92893 14.4988 8.25 12.4277 8.25Z" fill="currentColor" />
                        </svg>
                        <span class="lg:block hidden">Setting</span>
                    </a>
                </li>
            </ul>
        </div>
        <div class="flex items-center gap-5">
            <div x-data="{ fullScreen: false }">
                <button class="text-lightgray hover:text-primary block" x-bind:class="{ 'hidden': fullScreen, 'block': !fullScreen }" x-on:click="fullScreen = !fullScreen" @click="$store.app.toggleFullScreen()">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g opacity="0.4">
                            <path d="M19 7V1H13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M19 1L11.5 8.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </g>
                        <path d="M1 13V19H7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M8.5 11.5L1 19" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>

                </button>
                <button class="text-lightgray hidden" x-bind:class="{ 'block': fullScreen, 'hidden': !fullScreen }" x-on:click="fullScreen = !fullScreen" @click="$store.app.toggleFullScreen()">
                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g opacity="0.4">
                            <path d="M11.5 2.5V8.5H17.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                            <path d="M11.5 8.5L19 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        </g>
                        <path d="M8.5 17.5V11.5H2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                        <path d="M1 19L8.5 11.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                </button>
            </div>
            <div class="text-lightgray hover:text-primary duration-300">
                <a href="javascript:;" x-show="$store.app.mode === 'light'" @click="$store.app.toggleMode('dark')" style="display: none;">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M22 11.9999C22 17.5228 17.5228 21.9999 12 21.9999C10.8358 21.9999 9.71801 21.801 8.67887 21.4352C8.24138 20.3767 8 19.2165 8 17.9999C8 15.7787 8.80467 13.7454 10.1384 12.1757C11.31 13.8813 13.2744 14.9999 15.5 14.9999C17.8615 14.9999 19.9289 13.7405 21.0672 11.8568C21.3065 11.4607 22 11.5372 22 11.9999Z" fill="currentColor" />
                        <path d="M2 12C2 16.3586 4.78852 20.0659 8.67887 21.4353C8.24138 20.3768 8 19.2166 8 18C8 15.7788 8.80467 13.7455 10.1384 12.1758C9.42027 11.1303 9 9.86422 9 8.5C9 6.13845 10.2594 4.07105 12.1432 2.93276C12.5392 2.69347 12.4627 2 12 2C6.47715 2 2 6.47715 2 12Z" fill="currentColor" />
                    </svg>
                </a>
                <a href="javascript:;" x-show="$store.app.mode === 'dark'" @click="$store.app.toggleMode('light')">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M18 12C18 15.3137 15.3137 18 12 18C8.68629 18 6 15.3137 6 12C6 8.68629 8.68629 6 12 6C15.3137 6 18 8.68629 18 12Z" fill="currentColor" />
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 1.25C12.4142 1.25 12.75 1.58579 12.75 2V3C12.75 3.41421 12.4142 3.75 12 3.75C11.5858 3.75 11.25 3.41421 11.25 3V2C11.25 1.58579 11.5858 1.25 12 1.25ZM1.25 12C1.25 11.5858 1.58579 11.25 2 11.25H3C3.41421 11.25 3.75 11.5858 3.75 12C3.75 12.4142 3.41421 12.75 3 12.75H2C1.58579 12.75 1.25 12.4142 1.25 12ZM20.25 12C20.25 11.5858 20.5858 11.25 21 11.25H22C22.4142 11.25 22.75 11.5858 22.75 12C22.75 12.4142 22.4142 12.75 22 12.75H21C20.5858 12.75 20.25 12.4142 20.25 12ZM12 20.25C12.4142 20.25 12.75 20.5858 12.75 21V22C12.75 22.4142 12.4142 22.75 12 22.75C11.5858 22.75 11.25 22.4142 11.25 22V21C11.25 20.5858 11.5858 20.25 12 20.25Z" fill="currentColor" />
                        <g opacity="0.3">
                            <path d="M4.39838 4.39838C4.69127 4.10549 5.16615 4.10549 5.45904 4.39838L5.85188 4.79122C6.14477 5.08411 6.14477 5.55898 5.85188 5.85188C5.55898 6.14477 5.08411 6.14477 4.79122 5.85188L4.39838 5.45904C4.10549 5.16615 4.10549 4.69127 4.39838 4.39838Z" fill="currentColor" />
                            <path d="M19.6009 4.39864C19.8938 4.69153 19.8938 5.16641 19.6009 5.4593L19.2081 5.85214C18.9152 6.14503 18.4403 6.14503 18.1474 5.85214C17.8545 5.55924 17.8545 5.08437 18.1474 4.79148L18.5402 4.39864C18.8331 4.10575 19.308 4.10575 19.6009 4.39864Z" fill="currentColor" />
                            <path d="M18.1474 18.1474C18.4403 17.8545 18.9152 17.8545 19.2081 18.1474L19.6009 18.5402C19.8938 18.8331 19.8938 19.308 19.6009 19.6009C19.308 19.8938 18.8331 19.8938 18.5402 19.6009L18.1474 19.2081C17.8545 18.9152 17.8545 18.4403 18.1474 18.1474Z" fill="currentColor" />
                            <path d="M5.85188 18.1477C6.14477 18.4406 6.14477 18.9154 5.85188 19.2083L5.45904 19.6012C5.16615 19.8941 4.69127 19.8941 4.39838 19.6012C4.10549 19.3083 4.10549 18.8334 4.39838 18.5405L4.79122 18.1477C5.08411 17.8548 5.55898 17.8548 5.85188 18.1477Z" fill="currentColor" />
                        </g>
                    </svg>
                </a>
            </div>
            <div class="notification h-6" x-data="dropdown" @click.outside="open = false">
                <button type="button" class="text-lightgray hover:text-primary" @click="toggle()">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path opacity="0.3" d="M18.7491 9V9.7041C18.7491 10.5491 18.9903 11.3752 19.4422 12.0782L20.5496 13.8012C21.5612 15.3749 20.789 17.5139 19.0296 18.0116C14.4273 19.3134 9.57274 19.3134 4.97036 18.0116C3.21105 17.5139 2.43882 15.3749 3.45036 13.8012L4.5578 12.0782C5.00972 11.3752 5.25087 10.5491 5.25087 9.7041V9C5.25087 5.13401 8.27256 2 12 2C15.7274 2 18.7491 5.13401 18.7491 9Z" fill="currentColor" />
                        <path d="M12.75 6C12.75 5.58579 12.4142 5.25 12 5.25C11.5858 5.25 11.25 5.58579 11.25 6V10C11.25 10.4142 11.5858 10.75 12 10.75C12.4142 10.75 12.75 10.4142 12.75 10V6Z" fill="currentColor" />
                        <path d="M7.24316 18.5449C7.8941 20.5501 9.77767 21.9997 11.9998 21.9997C14.222 21.9997 16.1055 20.5501 16.7565 18.5449C13.611 19.1352 10.3886 19.1352 7.24316 18.5449Z" fill="currentColor" />
                    </svg>
                </button>
                <div class="noti-area space-y-[22px]" x-show="open" x-transition="" x-transition.duration.300ms="" style="display: none;">
                    <div class="flex items-center gap-2">
                        <h4 class="font-semibold text-dark dark:text-white">Notifications</h4>
                        <div x-data="{ dropdown: false}" class="dropdown ml-auto">
                            <a href="javaScript:;" class="text-lightgray h-3 flex items-center justify-center" @click="dropdown = !dropdown" @keydown.escape="dropdown = false">
                                <svg width="18" height="4" viewBox="0 0 18 4" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="2" cy="2" r="2" fill="currentColor" />
                                    <circle cx="9" cy="2" r="2" fill="currentColor" />
                                    <circle cx="16" cy="2" r="2" fill="currentColor" />
                                </svg>
                            </a>
                            <ul x-show="dropdown" @click.away="dropdown = false" x-transition="" x-transition.duration.300ms="" class="right-0 whitespace-nowrap">
                                <li><a href="javascript:;">All</a></li>
                                <li><a href="javascript:;">Read</a></li>
                                <li><a href="javascript:;">Unread</a></li>
                            </ul>
                        </div>
                    </div>
                    <ul class="mt-5 space-y-[22px]">
                        <li>
                            <a href="#" class="flex items-center gap-2.5">
                                <div class="w-9 h-9 bg-primary/10 rounded-full flex items-center justify-center shrink-0">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path opacity="0.5" fill-rule="evenodd" clip-rule="evenodd" d="M15.8333 9.94775V12.4998C15.8333 15.5104 13.5528 17.9882 10.625 18.3001V12.4998C10.625 12.1547 10.3452 11.8748 10 11.8748C9.65483 11.8748 9.37501 12.1547 9.37501 12.4998V18.3001C6.44724 17.9882 4.16668 15.5104 4.16668 12.4998V9.94775C4.16668 8.55831 5.03029 7.37058 6.25001 6.89204C6.62112 6.74645 7.02519 6.6665 7.44793 6.6665L12.5521 6.6665C12.9748 6.6665 13.3789 6.74645 13.75 6.89204C14.9697 7.37058 15.8333 8.55831 15.8333 9.94775Z" fill="#267DFF" />
                                        <path d="M15.8333 12.2918V11.0418H18.3333C18.6785 11.0418 18.9583 11.3216 18.9583 11.6668C18.9583 12.012 18.6785 12.2918 18.3333 12.2918H15.8333Z" fill="#267DFF" />
                                        <path d="M14.5796 16.1137C14.8386 15.7859 15.0632 15.4296 15.2479 15.0503L17.3629 16.108C17.6716 16.2623 17.7967 16.6378 17.6423 16.9465C17.488 17.2552 17.1125 17.3804 16.8038 17.226L14.5796 16.1137Z" fill="#267DFF" />
                                        <path d="M4.75217 15.0503C4.93683 15.4296 5.1614 15.7859 5.42042 16.1137L3.19622 17.226C2.88749 17.3804 2.51206 17.2552 2.35768 16.9465C2.20329 16.6378 2.32841 16.2623 2.63714 16.108L4.75217 15.0503Z" fill="#267DFF" />
                                        <path d="M4.16668 11.0418H1.66668C1.3215 11.0418 1.04168 11.3216 1.04168 11.6668C1.04168 12.012 1.3215 12.2918 1.66668 12.2918H4.16668V11.0418Z" fill="#267DFF" />
                                        <path d="M14.4612 7.27908L16.8038 6.10764C17.1125 5.95325 17.488 6.07837 17.6423 6.3871C17.7967 6.69583 17.6716 7.07126 17.3629 7.22564L15.3496 8.2324C15.1198 7.85843 14.8171 7.53406 14.4612 7.27908Z" fill="#267DFF" />
                                        <path d="M5.53879 7.27908C5.18297 7.53406 4.88024 7.85843 4.6504 8.2324L2.63714 7.22564C2.32841 7.07126 2.20329 6.69583 2.35768 6.3871C2.51206 6.07837 2.88749 5.95325 3.19622 6.10764L5.53879 7.27908Z" fill="#267DFF" />
                                        <path d="M13.75 6.89221V6.25C13.75 4.17893 12.0711 2.5 10 2.5C7.92895 2.5 6.25002 4.17893 6.25002 6.25V6.89221C6.62112 6.74661 7.02519 6.66667 7.44793 6.66667H12.5521C12.9748 6.66667 13.3789 6.74661 13.75 6.89221Z" fill="#267DFF" />
                                        <g opacity="0.5">
                                            <path d="M5.31339 1.31988C5.12192 1.60709 5.19952 1.99513 5.48673 2.1866L7.45307 3.49749C7.7877 3.18769 8.17893 2.93816 8.60951 2.76614L6.18011 1.14654C5.8929 0.955069 5.50486 1.03268 5.31339 1.31988Z" fill="#267DFF" />
                                            <path d="M12.547 3.49755C12.2124 3.18774 11.8212 2.9382 11.3906 2.76618L13.8201 1.14654C14.1073 0.955069 14.4953 1.03268 14.6868 1.31988C14.8783 1.60709 14.8006 1.99513 14.5134 2.1866L12.547 3.49755Z" fill="#267DFF" />
                                        </g>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10 11.875C10.3452 11.875 10.625 12.1548 10.625 12.5V18.3333H9.37502V12.5C9.37502 12.1548 9.65484 11.875 10 11.875Z" fill="#267DFF" />
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm text-dark dark:text-white">You have a bug that needs</p>
                                    <p class="text-xs text-gray mt-0.5">Just now</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center gap-2.5">
                                <div class="w-9 h-9 bg-purple/10 rounded-full flex items-center justify-center shrink-0">
                                    <svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <circle cx="10" cy="5.49984" r="3.33333" fill="#7B6AFE" />
                                        <ellipse opacity="0.5" cx="10" cy="14.6668" rx="5.83333" ry="3.33333" fill="#7B6AFE" />
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm text-dark dark:text-white">New user registered</p>
                                    <p class="text-xs text-gray mt-0.5">59 minutes ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <a href="#" class="flex items-center gap-2.5">
                                <div class="w-9 h-9 bg-primary/10 rounded-full flex items-center justify-center shrink-0">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path opacity="0.5" fill-rule="evenodd" clip-rule="evenodd" d="M15.8333 9.94775V12.4998C15.8333 15.5104 13.5528 17.9882 10.625 18.3001V12.4998C10.625 12.1547 10.3452 11.8748 10 11.8748C9.65483 11.8748 9.37501 12.1547 9.37501 12.4998V18.3001C6.44724 17.9882 4.16668 15.5104 4.16668 12.4998V9.94775C4.16668 8.55831 5.03029 7.37058 6.25001 6.89204C6.62112 6.74645 7.02519 6.6665 7.44793 6.6665L12.5521 6.6665C12.9748 6.6665 13.3789 6.74645 13.75 6.89204C14.9697 7.37058 15.8333 8.55831 15.8333 9.94775Z" fill="#267DFF" />
                                        <path d="M15.8333 12.2918V11.0418H18.3333C18.6785 11.0418 18.9583 11.3216 18.9583 11.6668C18.9583 12.012 18.6785 12.2918 18.3333 12.2918H15.8333Z" fill="#267DFF" />
                                        <path d="M14.5796 16.1137C14.8386 15.7859 15.0632 15.4296 15.2479 15.0503L17.3629 16.108C17.6716 16.2623 17.7967 16.6378 17.6423 16.9465C17.488 17.2552 17.1125 17.3804 16.8038 17.226L14.5796 16.1137Z" fill="#267DFF" />
                                        <path d="M4.75217 15.0503C4.93683 15.4296 5.1614 15.7859 5.42042 16.1137L3.19622 17.226C2.88749 17.3804 2.51206 17.2552 2.35768 16.9465C2.20329 16.6378 2.32841 16.2623 2.63714 16.108L4.75217 15.0503Z" fill="#267DFF" />
                                        <path d="M4.16668 11.0418H1.66668C1.3215 11.0418 1.04168 11.3216 1.04168 11.6668C1.04168 12.012 1.3215 12.2918 1.66668 12.2918H4.16668V11.0418Z" fill="#267DFF" />
                                        <path d="M14.4612 7.27908L16.8038 6.10764C17.1125 5.95325 17.488 6.07837 17.6423 6.3871C17.7967 6.69583 17.6716 7.07126 17.3629 7.22564L15.3496 8.2324C15.1198 7.85843 14.8171 7.53406 14.4612 7.27908Z" fill="#267DFF" />
                                        <path d="M5.53879 7.27908C5.18297 7.53406 4.88024 7.85843 4.6504 8.2324L2.63714 7.22564C2.32841 7.07126 2.20329 6.69583 2.35768 6.3871C2.51206 6.07837 2.88749 5.95325 3.19622 6.10764L5.53879 7.27908Z" fill="#267DFF" />
                                        <path d="M13.75 6.89221V6.25C13.75 4.17893 12.0711 2.5 10 2.5C7.92895 2.5 6.25002 4.17893 6.25002 6.25V6.89221C6.62112 6.74661 7.02519 6.66667 7.44793 6.66667H12.5521C12.9748 6.66667 13.3789 6.74661 13.75 6.89221Z" fill="#267DFF" />
                                        <g opacity="0.5">
                                            <path d="M5.31339 1.31988C5.12192 1.60709 5.19952 1.99513 5.48673 2.1866L7.45307 3.49749C7.7877 3.18769 8.17893 2.93816 8.60951 2.76614L6.18011 1.14654C5.8929 0.955069 5.50486 1.03268 5.31339 1.31988Z" fill="#267DFF" />
                                            <path d="M12.547 3.49755C12.2124 3.18774 11.8212 2.9382 11.3906 2.76618L13.8201 1.14654C14.1073 0.955069 14.4953 1.03268 14.6868 1.31988C14.8783 1.60709 14.8006 1.99513 14.5134 2.1866L12.547 3.49755Z" fill="#267DFF" />
                                        </g>
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M10 11.875C10.3452 11.875 10.625 12.1548 10.625 12.5V18.3333H9.37502V12.5C9.37502 12.1548 9.65484 11.875 10 11.875Z" fill="#267DFF" />
                                    </svg>
                                </div>
                                <div>
                                    <p class="text-sm text-dark dark:text-white">You have a bug that needs</p>
                                    <p class="text-xs text-gray mt-0.5">5 hours ago</p>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <div class="text-end">
                        <a href="javascript:;" class="text-gray font-semibold text-sm hover:text-primary duration-300">View More</a>
                    </div>
                </div>
            </div>
            <div class="profile z-10" x-data="dropdown" @click.outside="open = false">
                <button type="button" class="flex items-center gap-2.5" @click="toggle()">
                    <img class="h-[38px] w-[38px] rounded-full" src="assets/images/user.png" alt="Header Avatar">
                    <div class="text-start">
                        <div class="flex items-center gap-1">
                            <span class="hidden xl:block text-sm font-semibold"><?php echo e(auth()->user()->name); ?></span>
                            <svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1.29241 5.20759C0.901881 4.81707 0.90188 4.18391 1.29241 3.79338C1.68293 3.40286 2.31609 3.40286 2.70662 3.79338L5.99951 7.08627L9.2924 3.79338C9.68293 3.40286 10.3161 3.40286 10.7066 3.79338C11.0971 4.18391 11.0971 4.81707 10.7066 5.20759L6.70662 9.2076C6.31609 9.59812 5.68293 9.59812 5.2924 9.2076L1.29241 5.20759Z" fill="currentColor" />
                            </svg>
                        </div>
                        <span class="hidden xl:block text-xs text-lightgray">CEO & Founder</span>
                    </div>
                </button>
                <ul x-show="open" x-transition="" x-transition.duration.300ms="" style="display: none;">
                    <li>
                        <a href="javaScript:;" class="flex items-center gap-2">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="9.99996" cy="4.99984" r="3.33333" fill="currentColor" />
                                <ellipse opacity="0.33" cx="9.99996" cy="14.1668" rx="5.83333" ry="3.33333" fill="currentColor" />
                            </svg>
                            Profile
                        </a>
                    </li>
                    <li>
                        <a href="javaScript:;" class="flex items-center gap-2">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M10.3564 1.6665C9.42824 1.6665 8.58294 2.16709 6.89234 3.16827L6.32055 3.50688C4.62995 4.50806 3.78465 5.00865 3.32055 5.83317C2.85645 6.6577 2.85645 7.65887 2.85645 9.66122V10.3385C2.85645 12.3408 2.85645 13.342 3.32055 14.1665C3.78465 14.991 4.62995 15.4916 6.32055 16.4928L6.89234 16.8314C8.58294 17.8326 9.42824 18.3332 10.3564 18.3332C11.2846 18.3332 12.1299 17.8326 13.8205 16.8314L14.3923 16.4928C16.0829 15.4916 16.9282 14.991 17.3923 14.1665C17.8564 13.342 17.8564 12.3408 17.8564 10.3385V9.66122C17.8564 7.65887 17.8564 6.6577 17.3923 5.83317C16.9282 5.00865 16.0829 4.50806 14.3923 3.50688L13.8205 3.16827C12.1299 2.16709 11.2846 1.6665 10.3564 1.6665Z" fill="currentColor" />
                                <path d="M10.3564 6.875C8.63056 6.875 7.23145 8.27411 7.23145 10C7.23145 11.7259 8.63056 13.125 10.3564 13.125C12.0823 13.125 13.4814 11.7259 13.4814 10C13.4814 8.27411 12.0823 6.875 10.3564 6.875Z" fill="currentColor" />
                            </svg>
                            Setting
                        </a>
                    </li>
                    <li>
                        <a href="javaScript:;" class="flex items-center gap-2">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M15 11.6667C15 15.3486 12.0152 18.3333 8.33329 18.3333C7.3037 18.3333 6.32863 18.0999 5.45809 17.6832C5.15888 17.5399 4.8199 17.4896 4.49945 17.5754L3.47775 17.8487C2.67247 18.0642 1.93575 17.3275 2.15122 16.5222L2.42459 15.5005C2.51033 15.1801 2.46004 14.8411 2.31679 14.5419C1.90002 13.6713 1.66663 12.6963 1.66663 11.6667C1.66663 7.98477 4.65139 5 8.33329 5C12.0152 5 15 7.98477 15 11.6667ZM5.41663 12.5C5.87686 12.5 6.24996 12.1269 6.24996 11.6667C6.24996 11.2064 5.87686 10.8333 5.41663 10.8333C4.95639 10.8333 4.58329 11.2064 4.58329 11.6667C4.58329 12.1269 4.95639 12.5 5.41663 12.5ZM8.33329 12.5C8.79353 12.5 9.16663 12.1269 9.16663 11.6667C9.16663 11.2064 8.79353 10.8333 8.33329 10.8333C7.87306 10.8333 7.49996 11.2064 7.49996 11.6667C7.49996 12.1269 7.87306 12.5 8.33329 12.5ZM11.25 12.5C11.7102 12.5 12.0833 12.1269 12.0833 11.6667C12.0833 11.2064 11.7102 10.8333 11.25 10.8333C10.7897 10.8333 10.4166 11.2064 10.4166 11.6667C10.4166 12.1269 10.7897 12.5 11.25 12.5Z" fill="currentColor" />
                                <path opacity="0.3" d="M14.9868 12.0902C15.0767 12.053 15.1654 12.0134 15.2528 11.9716C15.4959 11.8552 15.7713 11.8143 16.0317 11.884L16.8618 12.1061C17.5161 12.2812 18.1147 11.6826 17.9396 11.0283L17.7175 10.1982C17.6479 9.9378 17.6887 9.66238 17.8051 9.41927C18.1437 8.71196 18.3334 7.91971 18.3334 7.08317C18.3334 4.09163 15.9082 1.6665 12.9167 1.6665C10.6583 1.6665 8.72276 3.04859 7.90967 5.01309C8.04977 5.0043 8.19105 4.99984 8.33337 4.99984C12.0153 4.99984 15 7.98461 15 11.6665C15 11.8088 14.9956 11.9501 14.9868 12.0902Z" fill="currentColor" />
                            </svg>
                            Message
                        </a>
                    </li>
                    <li>
                        <a href="javaScript:;" class="flex items-center gap-2">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M1.87496 10C1.87496 5.51269 5.51265 1.875 9.99996 1.875C14.4873 1.875 18.125 5.51269 18.125 10V12.3272C18.1901 12.3042 18.2602 12.2917 18.3333 12.2917C18.6785 12.2917 18.9583 12.5715 18.9583 12.9167V14.5833C18.9583 14.9285 18.6785 15.2083 18.3333 15.2083C17.9881 15.2083 17.7083 14.9285 17.7083 14.5833V14.1667H16.875V10C16.875 6.20304 13.7969 3.125 9.99996 3.125C6.203 3.125 3.12496 6.20304 3.12496 10V14.1667H2.29163V14.5833C2.29163 14.9285 2.0118 15.2083 1.66663 15.2083C1.32145 15.2083 1.04163 14.9285 1.04163 14.5833V12.9167C1.04163 12.5715 1.32145 12.2917 1.66663 12.2917C1.73968 12.2917 1.8098 12.3042 1.87496 12.3272V10Z" fill="currentColor" />
                                <path d="M6.66663 11.708C6.66663 11.0002 6.66663 10.6463 6.49189 10.4002C6.40396 10.2764 6.28724 10.1741 6.15102 10.1014C5.88034 9.95697 5.51475 9.99034 4.78357 10.0571C3.5515 10.1696 2.93546 10.2258 2.494 10.5337C2.27057 10.6896 2.083 10.8883 1.94308 11.1173C1.66663 11.5699 1.66663 12.1662 1.66663 13.3589V14.8086C1.66663 15.9894 1.66663 16.5798 1.9486 17.0357C2.05415 17.2064 2.18644 17.3603 2.34078 17.492C2.75315 17.8438 3.35507 17.9538 4.5589 18.1736C5.40606 18.3283 5.82965 18.4056 6.14226 18.2427C6.25762 18.1826 6.35958 18.1012 6.44235 18.0032C6.66663 17.7375 6.66663 17.322 6.66663 16.4911V11.708Z" fill="currentColor" />
                                <path d="M13.3333 11.708C13.3333 11.0002 13.3333 10.6463 13.508 10.4002C13.596 10.2764 13.7127 10.1741 13.8489 10.1014C14.1196 9.95697 14.4852 9.99034 15.2164 10.0571C16.4484 10.1696 17.0645 10.2258 17.5059 10.5337C17.7294 10.6896 17.9169 10.8883 18.0568 11.1173C18.3333 11.5699 18.3333 12.1662 18.3333 13.3589V14.8086C18.3333 15.9894 18.3333 16.5798 18.0513 17.0357C17.9458 17.2064 17.8135 17.3603 17.6591 17.492C17.2468 17.8438 16.6449 17.9538 15.441 18.1736C14.5939 18.3283 14.1703 18.4056 13.8577 18.2427C13.7423 18.1826 13.6403 18.1012 13.5576 18.0032C13.3333 17.7375 13.3333 17.322 13.3333 16.4911V11.708Z" fill="currentColor" />
                            </svg>
                            Support
                        </a>
                    </li>
                    <li>
                        <a href="javaScript:;" class="!text-danger flex items-center gap-2">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M10.3564 1.6665C9.42824 1.6665 8.58294 2.16709 6.89234 3.16827L6.32055 3.50688C4.62995 4.50806 3.78465 5.00865 3.32055 5.83317C2.85645 6.6577 2.85645 7.65887 2.85645 9.66122V10.3385C2.85645 12.3408 2.85645 13.342 3.32055 14.1665C3.78465 14.991 4.62995 15.4916 6.32055 16.4928L6.89234 16.8314C8.58294 17.8326 9.42824 18.3332 10.3564 18.3332C11.2846 18.3332 12.1299 17.8326 13.8205 16.8314L14.3923 16.4928C16.0829 15.4916 16.9282 14.991 17.3923 14.1665C17.8564 13.342 17.8564 12.3408 17.8564 10.3385V9.66122C17.8564 7.65887 17.8564 6.6577 17.3923 5.83317C16.9282 5.00865 16.0829 4.50806 14.3923 3.50688L13.8205 3.16827C12.1299 2.16709 11.2846 1.6665 10.3564 1.6665Z" fill="currentColor" />
                                <path d="M10.3564 6.875C8.63056 6.875 7.23145 8.27411 7.23145 10C7.23145 11.7259 8.63056 13.125 10.3564 13.125C12.0823 13.125 13.4814 11.7259 13.4814 10C13.4814 8.27411 12.0823 6.875 10.3564 6.875Z" fill="currentColor" />
                            </svg>
                            Sign Out
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <!-- End Topbar -->

    <!-- Start Content -->
    <div class="h-[calc(100vh-60px)] relative overflow-y-auto overflow-x-hidden p-5 sm:p-7 space-y-5">

        <!-- Start All Card -->
        <div class="flex flex-col gap-5 min-h-[calc(100vh-188px)] sm:min-h-[calc(100vh-204px)]">
            <div class="grid grid-cols-1">
                <div>
                    <ul class="font-semibold text-lightgray flex items-center gap-4 sm:gap-[30px] gap-y-4 whitespace-nowrap overflow-auto">
                        <li>
                            <a href="ecommerce.html" class="text-dark dark:text-white duration-300">Overview</a>
                        </li>
                        <li>
                            <a href="order-list.html" class="hover:text-dark duration-300 dark:hover:text-white">Order List</a>
                        </li>
                        <li>
                            <a href="accounts.html" class="hover:text-dark duration-300 dark:hover:text-white">Accounts</a>
                        </li>
                        <li>
                            <a href="payment.html" class="hover:text-dark duration-300 dark:hover:text-white">Payments</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <div class="flex items-center gap-2.5 flex-wrap">
                        <div class="shrink-0 h-[50px] w-[50px] flex items-center justify-center bg-primary/10 rounded-full text-primary">
                            <svg width="26" height="18" viewBox="0 0 26 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path opacity="0.3" d="M2.50817 5.51787C2.50817 5.64573 2.55896 5.76835 2.64937 5.85876C2.73978 5.94916 2.86239 5.99996 2.99025 5.99996C3.11544 6.00013 3.23593 5.95225 3.32684 5.86618C3.41776 5.78011 3.47217 5.66243 3.47885 5.53742C3.53923 5.01793 3.77246 4.53382 4.14108 4.16284C4.5097 3.79185 4.99232 3.55553 5.5114 3.49183C5.64099 3.49183 5.76526 3.44035 5.85689 3.34872C5.94852 3.2571 6 3.13282 6 3.00324C6 2.87365 5.94852 2.74938 5.85689 2.65775C5.76526 2.56612 5.64099 2.51464 5.5114 2.51464C4.99284 2.46858 4.50663 2.2429 4.13673 1.87657C3.76682 1.51023 3.53644 1.02623 3.48536 0.50814C3.48799 0.442351 3.4773 0.376708 3.45393 0.315155C3.43056 0.253601 3.39499 0.197407 3.34935 0.149946C3.30372 0.102485 3.24896 0.0647374 3.18837 0.0389701C3.12778 0.0132028 3.06261 -5.25387e-05 2.99677 1.56497e-07C2.86718 1.56497e-07 2.74291 0.0514771 2.65128 0.143107C2.55965 0.234736 2.50817 0.359012 2.50817 0.488596C2.46243 1.01167 2.23342 1.50178 1.86154 1.87246C1.48967 2.24314 0.998827 2.47058 0.475611 2.51464C0.412302 2.51549 0.34978 2.5288 0.291616 2.55382C0.233452 2.57883 0.180785 2.61506 0.136623 2.66043C0.0924617 2.7058 0.0576703 2.75943 0.034236 2.81825C0.0108016 2.87707 -0.000816702 2.93993 4.46117e-05 3.00324C0.00173187 3.13229 0.0537505 3.25559 0.145017 3.34686C0.236283 3.43813 0.359581 3.49014 0.48864 3.49183C1.01375 3.52711 1.50812 3.75207 1.87967 4.12482C2.25121 4.49756 2.47458 4.99266 2.50817 5.51787Z" fill="currentColor" />
                                <path d="M9.50871 0.780269L8.02311 6.78004C7.99157 6.92762 7.99232 7.08078 8.02532 7.22801C8.05831 7.37523 8.12267 7.51268 8.21357 7.63001C8.3032 7.74602 8.41645 7.83948 8.54499 7.90351C8.67353 7.96753 8.8141 8.0005 8.95637 7.99999H17.051C17.1933 8.0005 17.3339 7.96753 17.4624 7.90351C17.591 7.83948 17.7042 7.74602 17.7938 7.63001C17.8831 7.51183 17.9457 7.37399 17.9771 7.2268C18.0084 7.0796 18.0076 6.92687 17.9748 6.78004L16.4987 0.780269C16.4503 0.554696 16.329 0.353699 16.1553 0.21149C15.9817 0.0692809 15.7665 -0.0053507 15.5464 0.00029872H10.442C10.2251 -0.000725666 10.0144 0.0760254 9.84465 0.217856C9.67494 0.359687 9.55643 0.558098 9.50871 0.780269Z" fill="currentColor" />
                                <path opacity="0.3" d="M25.5045 2.39504H25.19C24.7888 2.34051 24.4166 2.15598 24.1303 1.86971C23.844 1.58343 23.6595 1.21121 23.605 0.810043V0.495464C23.5769 0.355711 23.5013 0.229994 23.391 0.139674C23.2807 0.049353 23.1425 0 23 0C22.8575 0 22.7193 0.049353 22.609 0.139674C22.4987 0.229994 22.4231 0.355711 22.395 0.495464V0.810043C22.3405 1.21121 22.156 1.58343 21.8697 1.86971C21.5834 2.15598 21.2112 2.34051 20.81 2.39504H20.4955C20.3557 2.42313 20.23 2.49874 20.1397 2.60902C20.0494 2.7193 20 2.85745 20 3C20 3.14255 20.0494 3.2807 20.1397 3.39098C20.23 3.50126 20.3557 3.57687 20.4955 3.60496H20.81C21.2112 3.65948 21.5834 3.84402 21.8697 4.13029C22.156 4.41656 22.3405 4.78879 22.395 5.18996V5.50453C22.4231 5.64429 22.4987 5.77 22.609 5.86032C22.7193 5.95064 22.8575 6 23 6C23.1425 6 23.2807 5.95064 23.391 5.86032C23.5013 5.77 23.5769 5.64429 23.605 5.50453V5.18996C23.6595 4.78879 23.844 4.41656 24.1303 4.13029C24.4166 3.84402 24.7888 3.65948 25.19 3.60496H25.5045C25.6443 3.57687 25.77 3.50126 25.8603 3.39098C25.9506 3.2807 26 3.14255 26 3C26 2.85745 25.9506 2.7193 25.8603 2.60902C25.77 2.49874 25.6443 2.42313 25.5045 2.39504Z" fill="currentColor" />
                                <path d="M10.5111 10.7802C10.4628 10.5547 10.3417 10.3537 10.1684 10.2115C9.99506 10.0693 9.78027 9.99465 9.56055 10.0003H4.45635C4.23663 9.99465 4.02184 10.0693 3.84854 10.2115C3.67523 10.3537 3.55413 10.5547 3.50585 10.7802L2.02306 16.7798C1.99159 16.9274 1.99234 17.0805 2.02527 17.2278C2.05819 17.375 2.12244 17.5124 2.21316 17.6298C2.30462 17.7484 2.42071 17.8435 2.55253 17.9076C2.68434 17.9718 2.82837 18.0033 2.97356 17.9997H11.0528C11.1948 18.0002 11.3351 17.9673 11.4634 17.9032C11.5917 17.8392 11.7048 17.7458 11.7942 17.6298C11.8833 17.5116 11.9458 17.3737 11.9771 17.2266C12.0084 17.0794 12.0076 16.9266 11.9748 16.7798L10.5111 10.7802Z" fill="currentColor" />
                                <path d="M22.5111 10.7803C22.4628 10.5547 22.3417 10.3537 22.1684 10.2115C21.9951 10.0693 21.7803 9.99465 21.5605 10.0003H16.4563C16.2366 9.99465 16.0218 10.0693 15.8485 10.2115C15.6752 10.3537 15.5541 10.5547 15.5058 10.7803L14.0231 16.78C13.9916 16.9276 13.9923 17.0808 14.0253 17.228C14.0582 17.3752 14.1224 17.5127 14.2132 17.63C14.3026 17.746 14.4157 17.8395 14.544 17.9035C14.6723 17.9675 14.8126 18.0005 14.9546 18H23.0528C23.1948 18.0005 23.3351 17.9675 23.4634 17.9035C23.5917 17.8395 23.7048 17.746 23.7942 17.63C23.8833 17.5118 23.9458 17.374 23.9771 17.2268C24.0084 17.0796 24.0076 16.9269 23.9748 16.78L22.5111 10.7803Z" fill="currentColor" />
                            </svg>
                        </div>
                        <div class="flex items-end gap-3">
                            <div class="flex-1">
                                <h4 class="text-lightgray text-sm">Total Earnings</h4>
                                <p class="font-bold text-lg mt-1.5">$98,457.20</p>
                            </div>
                            <div>
                                            <span class="flex items-center text-gray bg-gray/10 rounded-full py-1 px-2 gap-1 text-xs font-semibold">3.47%
                                                <svg width="10" height="10" class="inline-block" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.73684 9.21053C5.73684 9.64654 5.38338 10 4.94737 10C4.51135 10 4.15789 9.64654 4.15789 9.21053L4.15789 2.69543L2.34772 4.50561C2.03941 4.81392 1.53954 4.81392 1.23123 4.50561C0.922923 4.1973 0.922923 3.69743 1.23123 3.38913L4.38913 0.231232C4.53718 0.0831764 4.73799 -1.83028e-08 4.94737 0C5.15675 1.83066e-08 5.35756 0.0831765 5.50561 0.231232L8.66351 3.38913C8.97181 3.69743 8.97181 4.1973 8.66351 4.50561C8.3552 4.81392 7.85533 4.81392 7.54702 4.50561L5.73684 2.69543V9.21053Z" fill="currentColor" />
                                                </svg>
                                            </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <div class="flex items-center gap-2.5 flex-wrap">
                        <div class="shrink-0 h-[50px] w-[50px] flex items-center justify-center bg-pink/10 rounded-full text-pink">
                            <svg width="26" height="24" viewBox="0 0 26 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path opacity="0.3" d="M8.875 15C11.5674 15 13.75 12.8174 13.75 10.125C13.75 7.43261 11.5674 5.25 8.875 5.25C6.18261 5.25 4 7.43261 4 10.125C4 12.8174 6.18261 15 8.875 15Z" fill="currentColor" />
                                <path d="M1.95905 18.75C2.70819 17.5982 3.73317 16.6517 4.94092 15.9965C6.14867 15.3412 7.50095 14.998 8.87498 14.998C10.249 14.998 11.6013 15.3412 12.809 15.9965C14.0168 16.6517 15.0418 17.5982 15.7909 18.75" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                <path opacity="0.3" d="M17.125 15C18.499 14.9992 19.8513 15.3418 21.0592 15.9967C22.267 16.6517 23.292 17.5981 24.0409 18.75" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                <path d="M8.875 15C11.5674 15 13.75 12.8174 13.75 10.125C13.75 7.43261 11.5674 5.25 8.875 5.25C6.18261 5.25 4 7.43261 4 10.125C4 12.8174 6.18261 15 8.875 15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                <path opacity="0.3" d="M15.3147 5.59687C15.9816 5.3309 16.6989 5.2155 17.4156 5.25893C18.1322 5.30235 18.8304 5.50352 19.4602 5.84806C20.0901 6.19261 20.6361 6.67202 21.0592 7.25204C21.4823 7.83206 21.7721 8.49838 21.9078 9.20338C22.0435 9.90837 22.0219 10.6346 21.8444 11.3303C21.6669 12.026 21.3379 12.6738 20.881 13.2276C20.4241 13.7814 19.8505 14.2274 19.2012 14.5338C18.5519 14.8402 17.843 14.9994 17.125 15" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                        </div>
                        <div class="flex items-end gap-3">
                            <div class="flex-1">
                                <h4 class="text-lightgray text-sm">Customers</h4>
                                <p class="font-bold text-lg mt-1.5">$2,982.54</p>
                            </div>
                            <div>
                                            <span class="flex items-center text-gray bg-gray/10 rounded-full py-1 px-2 gap-1 text-xs font-semibold">9.69%
                                                <svg width="10" height="10" class="inline-block" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.73684 9.21053C5.73684 9.64654 5.38338 10 4.94737 10C4.51135 10 4.15789 9.64654 4.15789 9.21053L4.15789 2.69543L2.34772 4.50561C2.03941 4.81392 1.53954 4.81392 1.23123 4.50561C0.922923 4.1973 0.922923 3.69743 1.23123 3.38913L4.38913 0.231232C4.53718 0.0831764 4.73799 -1.83028e-08 4.94737 0C5.15675 1.83066e-08 5.35756 0.0831765 5.50561 0.231232L8.66351 3.38913C8.97181 3.69743 8.97181 4.1973 8.66351 4.50561C8.3552 4.81392 7.85533 4.81392 7.54702 4.50561L5.73684 2.69543V9.21053Z" fill="currentColor" />
                                                </svg>
                                            </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <div class="flex items-center gap-2.5 flex-wrap">
                        <div class="shrink-0 h-[50px] w-[50px] flex items-center justify-center bg-orange/10 rounded-full text-orange">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8.42229 20.6181C10.1779 21.5395 11.0557 22.0001 12 22.0001V12.0001L2.63802 7.07275C2.62423 7.09491 2.6107 7.11727 2.5974 7.13986C2 8.15436 2 9.41678 2 11.9416V12.0586C2 14.5834 2 15.8459 2.5974 16.8604C3.19479 17.8749 4.27063 18.4395 6.42229 19.5686L8.42229 20.6181Z" fill="currentColor" />
                                <path opacity="0.5" d="M17.5774 4.43152L15.5774 3.38197C13.8218 2.46066 12.944 2 11.9997 2C11.0554 2 10.1776 2.46066 8.42197 3.38197L6.42197 4.43152C4.31821 5.53552 3.24291 6.09982 2.6377 7.07264L11.9997 12L21.3617 7.07264C20.7564 6.09982 19.6811 5.53552 17.5774 4.43152Z" fill="currentColor" />
                                <path opacity="0.3" d="M21.4026 7.13986C21.3893 7.11727 21.3758 7.09491 21.362 7.07275L12 12.0001V22.0001C12.9443 22.0001 13.8221 21.5395 15.5777 20.6181L17.5777 19.5686C19.7294 18.4395 20.8052 17.8749 21.4026 16.8604C22 15.8459 22 14.5834 22 12.0586V11.9416C22 9.41678 22 8.15436 21.4026 7.13986Z" fill="currentColor" />
                                <path d="M6.32334 4.48382C6.35617 4.46658 6.38926 4.44922 6.42261 4.43172L7.91614 3.64795L17.0169 8.65338L21.0406 6.64152C21.1783 6.79745 21.298 6.96175 21.4029 7.13994C21.5525 7.39396 21.6646 7.66352 21.7487 7.96455L17.7503 9.96373V13.0002C17.7503 13.4144 17.4145 13.7502 17.0003 13.7502C16.5861 13.7502 16.2503 13.4144 16.2503 13.0002V10.7137L12.7503 12.4637V21.9042C12.4934 21.9682 12.2492 22.0002 12.0003 22.0002C11.7515 22.0002 11.5072 21.9682 11.2503 21.9042V12.4637L2.25195 7.96455C2.33601 7.66352 2.44813 7.39396 2.59771 7.13994C2.70264 6.96175 2.82232 6.79745 2.96001 6.64152L12.0003 11.1617L15.3865 9.46857L6.32334 4.48382Z" fill="currentColor" />
                            </svg>
                        </div>
                        <div class="flex items-end gap-3">
                            <div class="flex-1">
                                <h4 class="text-lightgray text-sm">Orders</h4>
                                <p class="font-bold text-lg mt-1.5">48982.54</p>
                            </div>
                            <div>
                                            <span class="flex items-center text-gray bg-gray/10 rounded-full py-1 px-2 gap-1 text-xs font-semibold">2.58%
                                                <svg width="10" height="10" class="inline-block rotate-180" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.73684 9.21053C5.73684 9.64654 5.38338 10 4.94737 10C4.51135 10 4.15789 9.64654 4.15789 9.21053L4.15789 2.69543L2.34772 4.50561C2.03941 4.81392 1.53954 4.81392 1.23123 4.50561C0.922923 4.1973 0.922923 3.69743 1.23123 3.38913L4.38913 0.231232C4.53718 0.0831764 4.73799 -1.83028e-08 4.94737 0C5.15675 1.83066e-08 5.35756 0.0831765 5.50561 0.231232L8.66351 3.38913C8.97181 3.69743 8.97181 4.1973 8.66351 4.50561C8.3552 4.81392 7.85533 4.81392 7.54702 4.50561L5.73684 2.69543V9.21053Z" fill="currentColor" />
                                                </svg>
                                            </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <div class="flex items-center gap-2.5 flex-wrap">
                        <div class="shrink-0 h-[50px] w-[50px] flex items-center justify-center bg-purple/10 rounded-full text-purple">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4.8916 9.61431C4.8916 9.21193 5.21525 8.88574 5.61449 8.88574H9.46991C9.86916 8.88574 10.1928 9.21193 10.1928 9.61431C10.1928 10.0167 9.86916 10.3429 9.46991 10.3429H5.61449C5.21525 10.3429 4.8916 10.0167 4.8916 9.61431Z" fill="currentColor" />
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M21.1884 10.0038C21.1262 9.99995 21.0584 9.99998 20.9881 10L20.9706 10H18.2149C15.9435 10 14 11.7361 14 14C14 16.2639 15.9435 18 18.2149 18H20.9706L20.9881 18C21.0584 18 21.1262 18 21.1884 17.9962C22.111 17.9397 22.927 17.2386 22.9956 16.2594C23.0001 16.1952 23 16.126 23 16.0619L23 16.0444V11.9556L23 11.9381C23 11.874 23.0001 11.8048 22.9956 11.7406C22.927 10.7614 22.111 10.0603 21.1884 10.0038ZM17.9706 15.0667C18.5554 15.0667 19.0294 14.5891 19.0294 14C19.0294 13.4109 18.5554 12.9333 17.9706 12.9333C17.3858 12.9333 16.9118 13.4109 16.9118 14C16.9118 14.5891 17.3858 15.0667 17.9706 15.0667Z" fill="currentColor" />
                                <path opacity="0.3" d="M21.1394 10.0015C21.1394 8.82091 21.0965 7.55447 20.3418 6.64658C20.2689 6.55894 20.1914 6.47384 20.1088 6.39124C19.3604 5.64288 18.4114 5.31076 17.239 5.15314C16.0998 4.99997 14.6442 4.99999 12.8064 5H10.6936C8.85583 4.99999 7.40019 4.99997 6.26098 5.15314C5.08856 5.31076 4.13961 5.64288 3.39124 6.39124C2.64288 7.13961 2.31076 8.08856 2.15314 9.26098C1.99997 10.4002 1.99999 11.8558 2 13.6936V13.8064C1.99999 15.6442 1.99997 17.0998 2.15314 18.239C2.31076 19.4114 2.64288 20.3604 3.39124 21.1088C4.13961 21.8571 5.08856 22.1892 6.26098 22.3469C7.40018 22.5 8.8558 22.5 10.6935 22.5H12.8064C14.6442 22.5 16.0998 22.5 17.239 22.3469C18.4114 22.1892 19.3604 21.8571 20.1088 21.1088C20.3133 20.9042 20.487 20.6844 20.6346 20.4486C21.0851 19.7291 21.1394 18.8473 21.1394 17.9985C21.0912 18 21.0404 18 20.9882 18L18.2149 18C15.9435 18 14 16.2639 14 14C14 11.7361 15.9435 10 18.2149 10L20.9881 10C21.0403 9.99999 21.0912 9.99997 21.1394 10.0015Z" fill="currentColor" />
                                <path d="M10.1015 2.57211L8 3.99253L6.26672 5.15237C7.40508 4.99997 8.85892 4.99999 10.6936 5H12.8064C14.6442 4.99998 16.0998 4.99997 17.239 5.15314C17.4682 5.18394 17.6888 5.22142 17.9011 5.26737L16 4L13.8875 2.57211C12.7589 1.8093 11.23 1.8093 10.1015 2.57211Z" fill="currentColor" />
                            </svg>
                        </div>
                        <div class="flex items-end gap-3">
                            <div class="flex-1">
                                <h4 class="text-lightgray text-sm">Available Balance</h4>
                                <p class="font-bold text-lg mt-1.5">$98,457.20</p>
                            </div>
                            <div>
                                            <span class="flex items-center text-gray bg-gray/10 rounded-full py-1 px-2 gap-1 text-xs font-semibold">4.23%
                                                <svg width="10" height="10" class="inline-block" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M5.73684 9.21053C5.73684 9.64654 5.38338 10 4.94737 10C4.51135 10 4.15789 9.64654 4.15789 9.21053L4.15789 2.69543L2.34772 4.50561C2.03941 4.81392 1.53954 4.81392 1.23123 4.50561C0.922923 4.1973 0.922923 3.69743 1.23123 3.38913L4.38913 0.231232C4.53718 0.0831764 4.73799 -1.83028e-08 4.94737 0C5.15675 1.83066e-08 5.35756 0.0831765 5.50561 0.231232L8.66351 3.38913C8.97181 3.69743 8.97181 4.1973 8.66351 4.50561C8.3552 4.81392 7.85533 4.81392 7.54702 4.50561L5.73684 2.69543V9.21053Z" fill="currentColor" />
                                                </svg>
                                            </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <div class="mb-[30px] flex items-center flex-wrap">
                        <h2 class="flex-1 font-semibold">Working Capital</h2>
                        <div>
                            <select class="form-select h-8 rounded-full border-none font-semibold text-xs">
                                <option>Last 7 days</option>
                                <option>Last 30 days</option>
                                <option>Last 90 days</option>
                            </select>
                        </div>
                    </div>
                    <div id="capital"></div>
                </div>
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <h2 class="mb-[30px] font-semibold">Project vs Action</h2>
                    <div id="projectvsaction"></div>
                </div>
            </div>
            <div class="grid grid-cols-1 gap-5">
                <div class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg">
                    <h2 class="mb-[30px] font-semibold">Order List</h2>
                    <div class="overflow-auto">
                        <table class="min-w-[640px] w-full product-table">
                            <thead>
                            <tr class="text-left">
                                <th>No</th>
                                <th>IDCustomer</th>
                                <th>Product</th>
                                <th>Customers</th>
                                <th>Location</th>
                                <th>Quantity</th>
                                <th>Status</th>
                                <th>Amount</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>1.</td>
                                <td>#6545</td>
                                <td>
                                    <div class="flex items-center gap-2.5">
                                        <img src="assets/images/product/1.png" class="w-[50px] rounded-full" alt="">
                                        <div class="flex-1 max-w-[200px] truncate">
                                            <p class="line-clamp-1 truncate">Speed Force : Knit</p>
                                            <p class="text-gray">Women</p>
                                        </div>
                                    </div>
                                </td>
                                <td>Ronald Richards</td>
                                <td>Celina, Delaware 10299</td>
                                <td>2</td>
                                <td><span class="bg-success text-white font-bold text-xs py-2 px-3 rounded-full">Paid</span></td>
                                <td>$215</td>
                            </tr>
                            <tr>
                                <td>2.</td>
                                <td>#5412</td>
                                <td>
                                    <div class="flex items-center gap-2.5">
                                        <img src="assets/images/product/2.png" class="w-[50px] rounded-full" alt="">
                                        <div class="flex-1 max-w-[200px] truncate">
                                            <p class="line-clamp-1 truncate">Assorted Cross Bag</p>
                                            <p class="text-gray">Men</p>
                                        </div>
                                    </div>
                                </td>
                                <td>Marvin McKinney</td>
                                <td>Cir. Syracuse, Connecticut 35624</td>
                                <td>3</td>
                                <td><span class="bg-orange text-white font-bold text-xs py-2 px-3 rounded-full">Unpaid</span></td>
                                <td>$542</td>
                            </tr>
                            <tr>
                                <td>3.</td>
                                <td>#6622</td>
                                <td>
                                    <div class="flex items-center gap-2.5">
                                        <img src="assets/images/product/3.png" class="w-[50px] rounded-full" alt="">
                                        <div class="flex-1 max-w-[200px] truncate">
                                            <p class="line-clamp-1 truncate">Galaxy Hi-Tech Exclusive</p>
                                            <p class="text-gray">Children</p>
                                        </div>
                                    </div>
                                </td>
                                <td>Jane Cooper</td>
                                <td>New Jersey 45463</td>
                                <td>5</td>
                                <td><span class="bg-primary text-white font-bold text-xs py-2 px-3 rounded-full">Done</span></td>
                                <td>$980</td>
                            </tr>
                            <tr>
                                <td>4.</td>
                                <td>#6425</td>
                                <td>
                                    <div class="flex items-center gap-2.5">
                                        <img src="assets/images/product/4.png" class="w-[50px] rounded-full" alt="">
                                        <div class="flex-1 max-w-[200px] truncate">
                                            <p class="line-clamp-1 truncate">Happy Days Wax Candle</p>
                                            <p class="text-gray">Women</p>
                                        </div>
                                    </div>
                                </td>
                                <td>Cameron Williamson</td>
                                <td>Pennsylvania 57867</td>
                                <td>1</td>
                                <td><span class="bg-success text-white font-bold text-xs py-2 px-3 rounded-full">Paid</span></td>
                                <td>$1450</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- End All Card -->

        <!-- Start Footer -->
        <footer class="bg-white dark:bg-dark dark:border-gray/20 border-2 border-lightgray/10 p-5 rounded-lg flex flex-wrap justify-center gap-3 sm:justify-between items-center">
            <p class="font-semibold">
                &copy;
                <script>
                    var year = new Date(); document.write(year.getFullYear());
                </script>
                DashHub
            </p>
            <ul class="sm:flex items-center text-dark dark:text-white gap-4 sm:gap-[30px] font-semibold hidden">
                <li><a href="javascirpt:;" class="hover:text-primary transition-all duration-300 cursor-pointer">About</a></li>
                <li><a href="javascirpt:;" class="hover:text-primary transition-all duration-300 cursor-pointer">Support</a></li>
                <li><a href="javascirpt:;" class="hover:text-primary transition-all duration-300 cursor-pointer">Contact Us</a></li>
            </ul>
        </footer>
        <!-- End Footer -->

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\create_users\resources\views/dashboard.blade.php ENDPATH**/ ?>